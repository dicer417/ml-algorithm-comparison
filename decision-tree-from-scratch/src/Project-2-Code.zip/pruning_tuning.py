import math
import pandas as pd
import os
from src.data_loader import DataLoader
from src.regression_tree import RegressionTree


class Pruner:
    def __init__(self, dataset):
        self.dataset = dataset
        self.data_loader = DataLoader(dataset=dataset)
        self.data_loader.load_data()
        self.data_loader.pre_process_data()
        self.data_loader.split_and_save_data()

    def create_trees(self, iterations=5):
        save_num = 1
        for ind in list(range(0, iterations)):
            # Randomly split the training data into 2 sets, with stratification
            self.data_loader.split_training_data()

            training_data = self.data_loader.trainingData
            training_set1 = training_data[training_data['set'] == 1].copy()
            training_set2 = training_data[training_data['set'] == 2].copy()

            # Normalize the numeric data
            training_set1 = self.data_loader.normalize_data(training_set1)
            training_set2 = self.data_loader.normalize_data(training_set2)
            tree = RegressionTree(self.data_loader)

            # First, create a tree from the first training set and save it
            tree.nodes = pd.DataFrame()
            tree.create_tree(data=training_set1)
            file_name = "data/trees/" + self.dataset + str(save_num) + ".csv"
            tree.nodes.to_csv(file_name)

            save_num = save_num + 1

            # Then, create a tree from the second training set and save it
            tree.nodes = pd.DataFrame()
            tree.create_tree(data=training_set2)
            file_name = "data/trees/" + self.dataset + str(save_num) + ".csv"
            tree.nodes.to_csv(file_name)

            save_num = save_num + 1


if __name__ == '__main__':
    os.chdir('C:\\Users\\toddi\\PycharmProjects\\Programming-Project-2')

    pruner = Pruner('abalone')
    pruner.create_trees(iterations=5)
    print(range(5))
